"""Import every model so Alembic autogenerate and relationships resolve."""

from app.models.audio import AudioAsset
from app.models.audit import AuditEvent
from app.models.job import GenerationChunk, GenerationJob
from app.models.model import ModelBenchmark, ModelDefinition, ModelInstallation
from app.models.project import Project, ProjectFolder
from app.models.user import User, Workspace, WorkspaceMember
from app.models.voice import Voice, VoiceAuthorization, VoiceSample

__all__ = [
    "AudioAsset",
    "AuditEvent",
    "GenerationChunk",
    "GenerationJob",
    "ModelBenchmark",
    "ModelDefinition",
    "ModelInstallation",
    "Project",
    "ProjectFolder",
    "User",
    "Voice",
    "VoiceAuthorization",
    "VoiceSample",
    "Workspace",
    "WorkspaceMember",
]