from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    JSON,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class Voice(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "voices"

    workspace_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("workspaces.id", ondelete="CASCADE"), nullable=False, index=True
    )
    owner_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    language: Mapped[str] = mapped_column(String(10), nullable=False, index=True)
    source: Mapped[str] = mapped_column(
        String(30), nullable=False, default="builtin"
    )  # builtin | cloned | designed
    model_installation_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("model_installations.id", ondelete="SET NULL"), nullable=True
    )
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_favorite: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    design_prompt: Mapped[str | None] = mapped_column(Text, nullable=True)

    owner: Mapped["User | None"] = relationship(back_populates="voices")
    workspace: Mapped["Workspace"] = relationship(back_populates="voices")
    samples: Mapped[list[VoiceSample]] = relationship(
        back_populates="voice", cascade="all, delete-orphan"
    )
    authorizations: Mapped[list[VoiceAuthorization]] = relationship(
        back_populates="voice", cascade="all, delete-orphan"
    )


class VoiceSample(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "voice_samples"

    voice_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("voices.id", ondelete="CASCADE"), nullable=False, index=True
    )
    storage_path: Mapped[str] = mapped_column(String(1000), nullable=False)
    original_filename: Mapped[str] = mapped_column(String(255), nullable=False)
    duration_seconds: Mapped[float] = mapped_column(Float, nullable=False)
    sample_rate: Mapped[int] = mapped_column(nullable=False)
    channels: Mapped[int] = mapped_column(nullable=False, default=1)
    format: Mapped[str] = mapped_column(String(10), nullable=False)
    file_size_bytes: Mapped[int] = mapped_column(nullable=False)
    is_reference: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    voice: Mapped[Voice] = relationship(back_populates="samples")


class VoiceAuthorization(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "voice_authorizations"
    __table_args__ = (UniqueConstraint("voice_id", name="uq_voice_authorization"),)

    voice_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("voices.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    speaker_name: Mapped[str] = mapped_column(String(200), nullable=False)
    consent_statement: Mapped[str] = mapped_column(Text, nullable=False)
    consent_metadata: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    authorized_by_user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    authorized_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default="now()"
    )

    voice: Mapped[Voice] = relationship(back_populates="authorizations")