'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
    Activity, AlertCircle, ArrowDownRight, CheckCircle2, ChevronDown,
    Clock3, Cpu, Gauge, Loader2, MemoryStick, Play, RefreshCw,
    Server, XCircle,
} from 'lucide-react'
import { api, ApiError } from '@/lib/api'
import { formatRelativeTime } from '@/lib/utils'
import type { BenchmarkOut, BenchmarkSummary, ModelInstallationOut } from '@/types/api'

type Sample = 'short' | 'medium' | 'long'
const SAMPLE_OPTIONS: { id: Sample; title: string; description: string }[] = [
    { id: 'short', title: 'Short', description: 'Quick response' },
    { id: 'medium', title: 'Medium', description: 'Typical sentence' },
    { id: 'long', title: 'Long', description: 'Extended speech' },
]

const panel = 'rounded-xl border border-border bg-bg-muted'

const field = 'studio-input'

const secondaryButton = 'studio-button-secondary'

const primaryButton = 'studio-button-primary'
function errorText(err: unknown): string {
    return err instanceof ApiError || err instanceof Error ? err.message : 'The request could not be completed.'
}
function numeric(value: number | null | undefined, digits = 2): string {
    return value != null && Number.isFinite(value) ? value.toFixed(digits) : '—'
}
function memory(value: number | null | undefined): string {
    if (value == null) return '—'
    return value >= 1024 ? `${(value / 1024).toFixed(2)} GB` : `${Math.round(value)} MB`
}

function rtfColor(value: number | null | undefined): string {
    if (value == null || !Number.isFinite(value)) {
        return 'text-fg-subtle'
    }

    if (value < 1) return 'text-success'
    if (value <= 2) return 'text-warning'

    return 'text-danger'
}
export default function BenchmarksPage() {
    const [models, setModels] = useState<ModelInstallationOut[]>([])
    const [summary, setSummary] = useState<BenchmarkSummary[]>([])
    const [details, setDetails] = useState<BenchmarkOut[]>([])
    const [manifestId, setManifestId] = useState('')
    const [samples, setSamples] = useState<Sample[]>(['short', 'medium'])
    const [coldStart, setColdStart] = useState(true)
    const [loading, setLoading] = useState(true)
    const [detailsLoading, setDetailsLoading] = useState(false)
    const [running, setRunning] = useState(false)
    const [refreshing, setRefreshing] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [notice, setNotice] = useState<string | null>(null)
    const [showGuide, setShowGuide] = useState(false)
    const detailRequest = useRef(0)
    const selectedRef = useRef('')

    const refresh = useCallback(async (initial = false) => {
        if (initial) setLoading(true)
        else setRefreshing(true)
        try {
            const [installations, summaries] = await Promise.all([
                api.models.list(),
                api.models.benchmarkSummary(),
            ])
            setModels(installations)
            setSummary(summaries)
            setManifestId(previous => {
                const next = installations.some(model => model.manifest_id === previous)
                    ? previous
                    : (installations[0]?.manifest_id ?? '')
                selectedRef.current = next
                return next
            })
            setError(null)
        } catch (err) {
            setError(errorText(err))
        } finally {
            setLoading(false)
            setRefreshing(false)
        }
    }, [])

    useEffect(() => {
        void refresh(true)
    }, [refresh])

    useEffect(() => {
        const requestId = ++detailRequest.current
        if (!manifestId) {
            setDetails([])
            setDetailsLoading(false)
            return
        }
        setDetails([])
        setDetailsLoading(true)
        void api.models.benchmarks(manifestId)
            .then(rows => {
                if (detailRequest.current === requestId) setDetails(rows)
            })
            .catch(err => {
                if (detailRequest.current === requestId) setError(errorText(err))
            })
            .finally(() => {
                if (detailRequest.current === requestId) setDetailsLoading(false)
            })
    }, [manifestId])

    const currentModel = models.find(model => model.manifest_id === manifestId)
    const successful = details.filter(row => row.success)
    const best = successful.filter(row => !row.cold_start && row.real_time_factor > 0)
        .reduce<number | null>((minimum, row) => minimum === null ? row.real_time_factor : Math.min(minimum, row.real_time_factor), null)
    const latest = details[0]
    const totalRuns = useMemo(() => summary.reduce((count, row) => count + row.runs, 0), [summary])
    const benchmarkedModels = summary.filter(row => row.runs > 0).length

    function toggleSample(sample: Sample) {
        setSamples(previous => previous.includes(sample)
            ? previous.filter(value => value !== sample)
            : SAMPLE_OPTIONS.filter(value => previous.includes(value.id) || value.id === sample).map(value => value.id))
    }

    async function runBenchmark() {
        if (!manifestId || samples.length === 0 || running) return
        const requestedModel = manifestId
        setRunning(true)
        setError(null)
        setNotice(null)
        try {
            const results = await api.models.runBenchmark({
                manifest_id: requestedModel,
                samples,
                include_cold_start: coldStart,
            })
            const successes = results.filter(row => row.success).length
            setNotice(`${successes} of ${results.length} benchmark runs completed successfully for ${currentModel?.definition.display_name ?? requestedModel}.`)
            await refresh()
            if (selectedRef.current === requestedModel) {
                const requestId = ++detailRequest.current
                setDetailsLoading(true)
                try {
                    const rows = await api.models.benchmarks(requestedModel)
                    if (detailRequest.current === requestId) setDetails(rows)
                } catch (err) {
                    if (detailRequest.current === requestId) setError(errorText(err))
                } finally {
                    if (detailRequest.current === requestId) setDetailsLoading(false)
                }
            }
        } catch (err) {
            setError(errorText(err))
        } finally {
            setRunning(false)
        }
    }

    return (

        <main className="studio-light-tools mx-auto w-full max-w-7xl space-y-7 px-4 py-6 text-slate-100 sm:px-6 lg:px-8">
            <header className="flex flex-wrap items-start justify-between gap-4">
                <div>
                    <div className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.15em] text-[#9299a8]">
                        <Server className="h-3.5 w-3.5" /> Models <span className="text-[#515867]">/</span> Benchmarks
                    </div>
                    <h1 className="text-2xl font-semibold tracking-tight text-[#f6f7fa] sm:text-[28px]">Model benchmarks</h1>
                    <p className="mt-1.5 max-w-2xl text-sm leading-6 text-[#9da4b2]">Compare local text-to-speech inference speed and memory usage across installed models.</p>
                </div>
                <button type="button" onClick={() => void refresh()} disabled={loading || refreshing || running} className={secondaryButton}>
                    <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} /> Refresh data
                </button>
            </header>

            {error && <div role="alert" className="flex items-start gap-3 rounded-lg border border-[#8c4249]/50 bg-[#3a2228]/70 px-4 py-3 text-sm text-[#ffc4c6]"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><span className="flex-1">{error}</span><button type="button" onClick={() => setError(null)} aria-label="Dismiss error"><XCircle className="h-4 w-4" /></button></div>}
            {notice && <div role="status" className="flex items-start gap-3 rounded-lg border border-[#326c5b] bg-[#18382f]/60 px-4 py-3 text-sm text-[#a4e7ce]"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" /><span className="flex-1">{notice}</span><button type="button" onClick={() => setNotice(null)} aria-label="Dismiss notification"><XCircle className="h-4 w-4" /></button></div>}

            <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4" aria-label="Benchmark overview">
                {[
                    { label: 'Registered models', value: models.length, icon: Server, foot: 'Available for testing' },
                    { label: 'Models benchmarked', value: benchmarkedModels, icon: Gauge, foot: 'With saved results' },
                    { label: 'Recorded runs', value: totalRuns, icon: Activity, foot: 'Across all models' },
                    { label: 'Selected best RTF', value: best === null ? '—' : numeric(best), icon: ArrowDownRight, foot: 'Successful warm runs · lower is better' },
                ].map(metric => {
                    const Icon = metric.icon
                    return <div key={metric.label} className={`${panel} min-w-0 p-5`}>
                        <div className="flex items-center justify-between gap-2"><p className="text-sm text-[#a1a8b5]">{metric.label}</p><Icon className="h-4 w-4 shrink-0 text-[#858da0]" /></div>
                        <p className="mt-3 text-[29px] font-semibold leading-none tracking-tight text-[#f5f6f9]">{loading ? '—' : metric.value}</p>
                        <p className="mt-3 text-xs text-[#81899a]">{metric.foot}</p>
                    </div>
                })}
            </section>

            <section className={`${panel} overflow-hidden`} aria-labelledby="run-heading">
                <div className="border-b border-[#30343e] px-5 py-5 sm:px-6">
                    <div className="flex items-center gap-2"><div className="rounded-lg bg-[#7569e9]/15 p-2 text-[#a69df9]"><Play className="h-4 w-4" /></div><h2 id="run-heading" className="text-base font-semibold">Run a benchmark</h2></div>
                    <p className="mt-2 text-sm leading-6 text-[#969eac]">Choose a model and text lengths to measure its CPU inference performance. Benchmarking can increase CPU and RAM usage while it runs.</p>
                </div>
                <div className="grid gap-6 p-5 sm:p-6 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
                    <div className="space-y-5">
                        <label className="block space-y-2"><span className="text-sm font-medium text-[#d5d9e2]">Model installation</span>
                            <select value={manifestId} disabled={loading || running} onChange={event => { selectedRef.current = event.target.value; setManifestId(event.target.value); setNotice(null) }} className={field}>
                                {models.length === 0 && <option value="">No registered models</option>}
                                {models.map(model => <option key={model.manifest_id} value={model.manifest_id}>{model.definition.display_name}</option>)}
                            </select>
                        </label>
                        {currentModel && <div className="flex flex-wrap items-center gap-2 text-xs text-[#a3aab8]">
                            <span className="rounded-md border border-[#343947] bg-[#222630] px-2.5 py-1">{currentModel.runtime}</span>
                            <span className="rounded-md border border-[#343947] bg-[#222630] px-2.5 py-1">{currentModel.device.toUpperCase()}</span>
                            {currentModel.quantization && <span className="rounded-md border border-[#343947] bg-[#222630] px-2.5 py-1">{currentModel.quantization}</span>}
                            <span className="min-w-0 break-all text-[#7d8697]">{currentModel.manifest_id}</span>
                        </div>}
                    </div>
                    <div className="space-y-5">
                        <fieldset disabled={running}>
                            <legend className="mb-2 text-sm font-medium text-[#d5d9e2]">Test samples</legend>
                            <div className="grid grid-cols-3 gap-2">
                                {SAMPLE_OPTIONS.map(option => {
                                    const active = samples.includes(option.id)
                                    return <button key={option.id} type="button" aria-pressed={active} onClick={() => toggleSample(option.id)} className={`min-w-0 rounded-lg border px-2 py-3 text-left transition disabled:opacity-50 ${active ? 'border-[#8e83ed] bg-[#7569e9]/15 text-[#e9e6ff]' : 'border-[#363b47] bg-[#12151b] text-[#a5acba] hover:border-[#636b7b]'}`}>
                                        <div className="flex items-center gap-1.5 text-sm font-medium"><span className={`h-2 w-2 rounded-full ${active ? 'bg-[#a89eff]' : 'bg-[#5b6372]'}`} />{option.title}</div>
                                        <p className="mt-1 text-[11px] leading-4 text-[#8e96a6]">{option.description}</p>
                                    </button>
                                })}
                            </div>
                        </fieldset>
                        <label className="flex cursor-pointer items-start gap-3 rounded-lg border border-[#363b47] bg-[#12151b] px-3 py-3">
                            <input type="checkbox" checked={coldStart} disabled={running} onChange={event => setColdStart(event.target.checked)} className="mt-0.5 h-4 w-4 accent-[#8377f1]" />
                            <span><span className="block text-sm font-medium text-[#e1e4eb]">Include cold-start test</span><span className="mt-0.5 block text-xs leading-5 text-[#929aaa]">Also measure the initial model-loading overhead.</span></span>
                        </label>
                    </div>
                </div>
                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#30343e] bg-[#171a20] px-5 py-4 sm:px-6">
                    <p className="max-w-lg text-xs leading-5 text-[#929aaa]">{running ? 'Benchmark running. Keep this page open until the request finishes.' : 'The API performs the benchmark separately from the inference worker.'}</p>
                    <button type="button" onClick={() => void runBenchmark()} disabled={loading || running || !manifestId || samples.length === 0} className={primaryButton}>
                        {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}{running ? 'Running benchmark…' : 'Run benchmark'}
                    </button>
                </div>
            </section>

            <section className={`${panel} overflow-hidden`} aria-labelledby="comparison-heading">
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#30343e] px-5 py-5 sm:px-6">
                    <div><h2 id="comparison-heading" className="text-base font-semibold">Model comparison</h2><p className="mt-1 text-sm text-[#929aaa]">Aggregated benchmark history for each installation.</p></div>
                    <span className="rounded-md border border-[#343947] px-2.5 py-1 text-xs text-[#a1a8b6]">{summary.length} entries</span>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[760px] border-collapse text-left text-sm">
                        <thead className="bg-[#15181e] text-xs font-medium uppercase tracking-wider text-[#929aaa]"><tr>
                            <th scope="col" className="px-5 py-3.5 font-medium sm:pl-6">Model</th>
                            <th scope="col" className="px-4 py-3.5 font-medium">Runs</th>
                            <th scope="col" className="px-4 py-3.5 font-medium">Best RTF</th>
                            <th scope="col" className="px-4 py-3.5 font-medium">Worst RTF</th>
                            <th scope="col" className="px-4 py-3.5 font-medium">Peak memory</th>
                            <th scope="col" className="px-5 py-3.5 font-medium">Last run</th>
                        </tr></thead>
                        <tbody className="divide-y divide-[#2c303a]">
                            {loading && <tr><td colSpan={6} className="px-6 py-10 text-center text-[#929aaa]"><Loader2 className="mr-2 inline h-4 w-4 animate-spin" />Loading benchmark history…</td></tr>}
                            {!loading && summary.length === 0 && <tr><td colSpan={6} className="px-6 py-12 text-center text-[#929aaa]">No benchmark results yet. Run a test above to start comparing models.</td></tr>}
                            {!loading && summary.map(row => <tr key={row.manifest_id} className={`transition hover:bg-[#222630] ${row.manifest_id === manifestId ? 'bg-[#7569e9]/[0.055]' : ''}`}>
                                <td className="px-5 py-4 sm:pl-6"><button type="button" onClick={() => { selectedRef.current = row.manifest_id; setManifestId(row.manifest_id) }} className="text-left font-medium text-[#e9ebf1] hover:text-[#b9b2ff]">{row.display_name}</button><p className="mt-1 max-w-[240px] truncate text-xs text-[#818a9b]">{row.manifest_id}</p></td>
                                <td className="px-4 py-4 tabular-nums text-[#c5cad4]">{row.runs}</td>
                                <td className={`px-4 py-4 font-semibold tabular-nums ${rtfColor(row.best_rtf)}`}>{numeric(row.best_rtf)}{row.best_rtf != null && <span className="ml-1 text-xs font-normal text-[#8c94a4]">×</span>}</td>
                                <td className="px-4 py-4 tabular-nums text-[#c5cad4]">{numeric(row.worst_rtf)}</td>
                                <td className="px-4 py-4 tabular-nums text-[#c5cad4]">{memory(row.peak_ram_mb)}</td>
                                <td className="px-5 py-4 text-[#a5acb9]">{row.last_run_at ? formatRelativeTime(row.last_run_at) : '—'}</td>
                            </tr>)}
                        </tbody>
                    </table>
                </div>
            </section>

            <section className={`${panel} overflow-hidden`} aria-labelledby="detail-heading">
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#30343e] px-5 py-5 sm:px-6">
                    <div><h2 id="detail-heading" className="text-base font-semibold">Detailed results</h2><p className="mt-1 text-sm text-[#929aaa]">{currentModel?.definition.display_name ?? 'Select a model'} · {details.length} saved runs</p></div>
                    {latest && <span className="inline-flex items-center gap-1.5 text-xs text-[#919aaa]"><Clock3 className="h-3.5 w-3.5" /> Most recent results shown below</span>}
                </div>
                {detailsLoading ? <div className="flex items-center justify-center gap-2 px-5 py-12 text-sm text-[#929aaa]"><Loader2 className="h-4 w-4 animate-spin" />Loading results…</div>
                    : details.length === 0 ? <div className="px-5 py-12 text-center"><Gauge className="mx-auto h-7 w-7 text-[#737c8e]" /><p className="mt-3 text-sm font-medium text-[#d4d8e1]">No results for this model</p><p className="mt-1 text-sm text-[#919aaa]">Run a benchmark to populate its performance history.</p></div>
                        : <div className="overflow-x-auto"><table className="w-full min-w-[900px] text-left text-sm"><thead className="bg-[#15181e] text-xs uppercase tracking-wider text-[#929aaa]"><tr>
                            <th className="px-5 py-3.5 font-medium sm:pl-6">Sample</th><th className="px-4 py-3.5 font-medium">Start</th><th className="px-4 py-3.5 font-medium">Generate</th><th className="px-4 py-3.5 font-medium">Audio</th><th className="px-4 py-3.5 font-medium">RTF</th><th className="px-4 py-3.5 font-medium">Peak RAM</th><th className="px-4 py-3.5 font-medium">CPU</th><th className="px-5 py-3.5 font-medium">Result</th>
                        </tr></thead><tbody className="divide-y divide-[#2c303a]">{details.map(row => <tr key={row.id} className="hover:bg-[#222630]">
                            <td className="px-5 py-4 font-medium capitalize text-[#e4e7ee] sm:pl-6">{row.sample_name}</td>
                            <td className="px-4 py-4 text-[#a7afbc]">{row.cold_start ? 'Cold' : 'Warm'}</td>
                            <td className="px-4 py-4 tabular-nums text-[#c9ced8]">{numeric(row.generation_time_seconds)} s</td>
                            <td className="px-4 py-4 tabular-nums text-[#c9ced8]">{numeric(row.audio_duration_seconds)} s</td>
                            <td className={`px-4 py-4 font-semibold tabular-nums ${rtfColor(row.real_time_factor)}`}>{row.real_time_factor > 0 ? numeric(row.real_time_factor) : '—'}</td>
                            <td className="px-4 py-4 tabular-nums text-[#c9ced8]">{memory(row.peak_ram_mb)}</td>
                            <td className="px-4 py-4 tabular-nums text-[#c9ced8]">{row.cpu_percent != null ? `${numeric(row.cpu_percent, 1)}%` : '—'}</td>
                            <td className="px-5 py-4">{row.success ? <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#76d5b3]"><CheckCircle2 className="h-3.5 w-3.5" />Passed</span> : <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#f19a9a]" title={row.error_message ?? undefined}><XCircle className="h-3.5 w-3.5" />Failed{row.error_message ? `: ${row.error_message}` : ''}</span>}</td>
                        </tr>)}</tbody></table></div>}
            </section>

            <section className={`${panel} overflow-hidden`}>
                <button type="button" onClick={() => setShowGuide(value => !value)} aria-expanded={showGuide} className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left hover:bg-[#222630] sm:px-6">
                    <span className="flex items-center gap-2 text-sm font-medium text-[#dfe2e9]"><Gauge className="h-4 w-4 text-[#a69df9]" />Understanding benchmark metrics</span>
                    <ChevronDown className={`h-4 w-4 text-[#9aa2b1] transition-transform ${showGuide ? 'rotate-180' : ''}`} />
                </button>
                {showGuide && <div className="grid gap-5 border-t border-[#30343e] px-5 py-5 text-sm leading-6 text-[#a7afbc] sm:grid-cols-2 sm:px-6">
                    <div><p className="mb-1 font-medium text-[#e1e4ec]">Real-time factor (RTF)</p><p>Generation time divided by audio duration. Below 1.0 means faster than real time. Lower is better, but compare equivalent sample lengths and conditions.</p></div>
                    <div><p className="mb-1 font-medium text-[#e1e4ec]">Cold vs warm start</p><p>A cold test includes initial loading overhead. Warm tests reflect subsequent synthesis. Compare like-for-like runs.</p></div>
                    <div><p className="mb-1 font-medium text-[#e1e4ec]">Peak RAM</p><p>Maximum observed process memory during a test, not just the size of model weights.</p></div>
                    <div><p className="mb-1 font-medium text-[#e1e4ec]">CPU usage</p><p>Observed CPU utilization during benchmarking. Results can vary with other applications and background workloads.</p></div>
                </div>}
            </section>
            <p className="flex items-center gap-2 text-xs text-[#778091]"><Cpu className="h-3.5 w-3.5" /><MemoryStick className="h-3.5 w-3.5" />Measurements reflect your local machine and installed runtimes; they are not standardized cross-device scores.</p>
        </main>
    )
}
