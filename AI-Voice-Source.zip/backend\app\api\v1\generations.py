
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, status

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession


from app.api.deps import current_user, db_session
from app.core.exceptions import NotFoundError
from app.models.job import GenerationJob
from app.models.user import User, Workspace
from app.schemas.job import GenerationJobOut, GenerationSubmitRequest

router = APIRouter()


# Eagerly load relationships to prevent MissingGreenlet errors.
def job_query():
    return select(GenerationJob).options(
        selectinload(GenerationJob.chunks),
        selectinload(GenerationJob.audio_asset),
    )


@router.post("", response_model=GenerationJobOut, status_code=status.HTTP_201_CREATED)
async def submit_generation(
    payload: GenerationSubmitRequest,
    user: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> GenerationJobOut:
    if payload.idempotency_key:
        existing = await session.scalar(
            select(GenerationJob).where(
                GenerationJob.idempotency_key == payload.idempotency_key
            )
        )
        if existing is not None:
            return GenerationJobOut.model_validate(existing)

    workspace = await session.scalar(select(Workspace).limit(1))
    if workspace is None:
        raise NotFoundError("Workspace", "default")

    job = GenerationJob(
        workspace_id=workspace.id,
        created_by_user_id=user.id,
        model_installation_id=payload.model_installation_id,
        voice_id=payload.voice_id,
        project_id=payload.project_id,
        status="queued",
        text=payload.text,
        language=payload.language,
        settings=payload.settings,
        is_long_form=payload.long_form,
        progress_current=0,
        progress_total=1 if not payload.long_form else 0,
        idempotency_key=payload.idempotency_key,
    )
    session.add(job)
    try:
        await session.commit()
    except IntegrityError:
        # Two concurrent requests with the same key; return the winner.
        await session.rollback()
        existing = await session.scalar(
            select(GenerationJob).where(
                GenerationJob.idempotency_key == payload.idempotency_key
            )
        )
        if existing is None:
            raise
        return GenerationJobOut.model_validate(existing)
    await session.refresh(job)
    return GenerationJobOut.model_validate(job)
    


@router.get("", response_model=list[GenerationJobOut])
async def list_generations(
    limit: int = 50,
    offset: int = 0,
    _: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> list[GenerationJobOut]:

    rows = (
        await session.scalars(
            job_query()
            .order_by(GenerationJob.created_at.desc())
            .limit(limit)
            .offset(offset)
        )
    ).all()

    return [
        GenerationJobOut.model_validate(row)
        for row in rows
    ]


@router.get("/{job_id}", response_model=GenerationJobOut)
async def get_generation(
    job_id: uuid.UUID,
    _: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> GenerationJobOut:

    job = await session.scalar(
        job_query().where(GenerationJob.id == job_id)
    )

    if job is None:
        raise NotFoundError("GenerationJob", str(job_id))

    return GenerationJobOut.model_validate(job)


@router.post("/{job_id}/cancel", response_model=GenerationJobOut)
async def cancel_generation(
    job_id: uuid.UUID,
    _: User = Depends(current_user),
    session: AsyncSession = Depends(db_session),
) -> GenerationJobOut:

    job = await session.scalar(
        job_query().where(GenerationJob.id == job_id)
    )

    if job is None:
        raise NotFoundError("GenerationJob", str(job_id))

    if job.status in {"completed", "failed", "cancelled"}:
        from app.core.exceptions import AppError, ErrorCode

        raise AppError(
            ErrorCode.JOB_ALREADY_TERMINAL,
            "Job is already terminal.",
            status_code=409,
        )

    job.cancellation_requested = True

    if job.status == "queued":
        job.status = "cancelled"

    await session.commit()

    # Reload relationships after commit.
    result = await session.scalar(
        job_query().where(GenerationJob.id == job_id)
    )

    if result is None:
        raise NotFoundError("GenerationJob", str(job_id))

    return GenerationJobOut.model_validate(result)
