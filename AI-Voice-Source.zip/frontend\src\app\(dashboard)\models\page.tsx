
'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
    Activity,
    AlertCircle,
    Box,
    Check,
    CheckCircle2,
    ChevronDown,
    Cpu,
    Database,
    HardDrive,
    Layers3,
    Loader2,
    Play,
    RefreshCw,
    Search,
    Server,
    ShieldCheck,
    SlidersHorizontal,
    StopCircle,
    X,
} from 'lucide-react'

import { api, ApiError } from '@/lib/api'
import type { ModelInstallationOut } from '@/types/api'

type ModelAction = 'validate' | 'load' | 'unload'
type Filter = 'all' | 'loaded' | 'unloaded' | 'errors'

type BusyOperation = {
    id: string
    action: ModelAction
} | null

function formatLabel(value: string | null | undefined) {
    if (!value) return 'Not specified'

    const labels: Record<string, string> = {
        cpu: 'CPU',
        cuda: 'CUDA',
        mnn: 'MNN',
        piper: 'Piper',
        kokoro: 'Kokoro',
        qwen_mnn: 'Qwen MNN',
        qwen_mnn_cpu: 'Qwen MNN',
        fp16: 'FP16',
        fp32: 'FP32',
        int8: 'INT8',
        q8: 'Q8',
        q4: 'Q4',
    }

    return labels[value.toLowerCase()] ??
        value.replace(/[_-]/g, ' ')
}

function getErrorMessage(error: unknown, fallback: string) {
    if (error instanceof ApiError) return error.message
    if (error instanceof Error) return error.message
    return fallback
}

function getRuntimeState(model: ModelInstallationOut) {
    switch (model.loading_state) {
        case 'loaded':
            return {
                label: 'Loaded',
                description: 'Reported as loaded',
                dot: 'bg-[rgb(var(--color-success))]',
                text: 'text-[rgb(var(--color-success))]',
                background: 'bg-[rgb(var(--color-success)/0.09)]',
                border: 'border-[rgb(var(--color-success)/0.25)]',
            }

        case 'loading':
            return {
                label: 'Loading',
                description: 'Load operation pending',
                dot: 'bg-[rgb(var(--color-warning))]',
                text: 'text-[rgb(var(--color-warning))]',
                background: 'bg-[rgb(var(--color-warning)/0.09)]',
                border: 'border-[rgb(var(--color-warning)/0.25)]',
            }

        case 'error':
            return {
                label: 'Error',
                description: 'Model operation failed',
                dot: 'bg-[rgb(var(--color-danger))]',
                text: 'text-[rgb(var(--color-danger))]',
                background: 'bg-[rgb(var(--color-danger)/0.09)]',
                border: 'border-[rgb(var(--color-danger)/0.25)]',
            }

        default:
            return {
                label: 'Unloaded',
                description: 'Not loaded',
                dot: 'bg-[rgb(var(--color-fg-subtle))]',
                text: 'text-[rgb(var(--color-fg))]',
                background: 'bg-[rgb(var(--color-bg-elevated))]',
                border: 'border-[rgb(var(--color-border))]',
            }
    }
}

function getInstallationState(state: string) {
    switch (state) {
        case 'installed':
        case 'validated':
            return {
                label: state === 'installed' ? 'Installed' : 'Validated',
                icon: CheckCircle2,
                className:
                    'border-[rgb(var(--color-success)/0.25)] bg-[rgb(var(--color-success)/0.09)] text-[rgb(var(--color-success))]',
            }

        case 'invalid':
            return {
                label: 'Invalid',
                icon: AlertCircle,
                className:
                    'border-[rgb(var(--color-danger)/0.25)] bg-[rgb(var(--color-danger)/0.09)] text-[rgb(var(--color-danger))]',
            }

        default:
            return {
                label: 'Registered',
                icon: Database,
                className:
                    'border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-elevated))] text-[rgb(var(--color-fg))]',
            }
    }
}

function ModelIcon({ runtime }: { runtime: string }) {
    const normalized = runtime.toLowerCase()

    const Icon =
        normalized.includes('piper')
            ? Activity
            : normalized.includes('kokoro')
                ? Layers3
                : normalized.includes('qwen')
                    ? Cpu
                    : Box

    return (
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[rgb(var(--color-accent)/0.3)] bg-[rgb(var(--color-accent)/0.12)]">
            <Icon className="h-5 w-5 text-[rgb(142_91_34)]" strokeWidth={1.7} />
        </div>
    )
}

function StatCard({
    label,
    value,
    description,
    icon: Icon,
}: {
    label: string
    value: number
    description: string
    icon: typeof Box
}) {
    return (
        <div className="rounded-xl border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))] px-5 py-4">
            <div className="flex items-center justify-between gap-3">
                <span className="text-sm font-medium text-[rgb(var(--color-fg-muted))]">
                    {label}
                </span>

                <Icon className="h-[18px] w-[18px] text-[rgb(var(--color-fg-subtle))]" />
            </div>

            <div className="mt-3 text-[30px] font-semibold leading-none tracking-tight text-[rgb(var(--color-fg))]">
                {value.toString().padStart(2, '0')}
            </div>

            <p className="mt-2 text-xs text-[rgb(var(--color-fg-subtle))]">
                {description}
            </p>
        </div>
    )
}

function ModelCard({
    model,
    busy,
    onAction,
}: {
    model: ModelInstallationOut
    busy: BusyOperation
    onAction: (id: string, action: ModelAction) => void
}) {
    const [detailsOpen, setDetailsOpen] = useState(false)

    const runtimeState = getRuntimeState(model)
    const installationState = getInstallationState(
        model.installation_state
    )

    const InstallationIcon = installationState.icon

    const isBusy = busy?.id === model.manifest_id
    const anyBusy = busy !== null

    const isLoaded = model.loading_state === 'loaded'
    const isLoading = model.loading_state === 'loading'

    const canLoad = !anyBusy && !isLoaded && !isLoading
    const canUnload = !anyBusy && isLoaded

    return (
        <article className="overflow-hidden rounded-xl border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))] transition-colors hover:border-[rgb(var(--color-border-strong))]">
            <div className="p-5 sm:p-6">
                <div className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
                    <div className="flex min-w-0 items-start gap-4">
                        <ModelIcon runtime={model.runtime} />

                        <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                                <h3 className="text-base font-semibold tracking-tight text-[rgb(var(--color-fg))] sm:text-[17px]">
                                    {model.definition.display_name}
                                </h3>

                                {model.is_active_model && (
                                    <span className="rounded-md border border-[rgb(var(--color-accent)/0.3)] bg-[rgb(var(--color-accent)/0.12)] px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-[rgb(142_91_34)]">
                                        Active
                                    </span>
                                )}
                            </div>

                            <p className="mt-1 break-all font-mono text-xs text-[rgb(var(--color-fg-subtle))]">
                                {model.manifest_id}
                            </p>

                            <div className="mt-4 flex flex-wrap gap-2">
                                {[
                                    formatLabel(model.runtime),
                                    formatLabel(model.device),
                                    model.quantization
                                        ? formatLabel(model.quantization)
                                        : 'Default precision',
                                ].map((item, index) => (
                                    <span
                                        key={`${item}-${index}`}
                                        className="rounded-md border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-elevated))] px-2.5 py-1 text-[11px] font-medium text-[rgb(var(--color-fg))]"
                                    >
                                        {item}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="flex shrink-0 flex-wrap items-center gap-2 sm:justify-end">
                        <span
                            className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium ${installationState.className}`}
                        >
                            <InstallationIcon className="h-3.5 w-3.5" />
                            {installationState.label}
                        </span>

                        <span
                            className={`inline-flex items-center gap-2 rounded-md border px-2.5 py-1.5 text-xs font-medium ${runtimeState.background} ${runtimeState.border} ${runtimeState.text}`}
                        >
                            {isLoading ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                                <span
                                    className={`h-1.5 w-1.5 rounded-full ${runtimeState.dot}`}
                                />
                            )}

                            {runtimeState.label}
                        </span>
                    </div>
                </div>

                {model.last_error && (
                    <div
                        role="alert"
                        className="mt-5 flex items-start gap-2.5 rounded-lg border border-[rgb(var(--color-danger)/0.25)] bg-[rgb(var(--color-danger)/0.06)] px-3.5 py-3"
                    >
                        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-[rgb(var(--color-danger))]" />

                        <div className="min-w-0">
                            <p className="text-xs font-semibold text-[rgb(var(--color-danger))]">
                                Last reported error
                            </p>

                            <p className="mt-1 break-words text-xs leading-5 text-[rgb(var(--color-danger))]">
                                {model.last_error}
                            </p>
                        </div>
                    </div>
                )}

                <div className="mt-5 flex flex-col gap-4 border-t border-[rgb(var(--color-border))] pt-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-2 text-xs text-[rgb(var(--color-fg-muted))]">
                        <span
                            className={`h-2 w-2 rounded-full ${runtimeState.dot}`}
                        />

                        <span>{runtimeState.description}</span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                        <button
                            type="button"
                            disabled={anyBusy}
                            onClick={() => onAction(model.manifest_id, 'validate')}
                            className="inline-flex min-h-9 items-center justify-center gap-2 rounded-lg border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-elevated))] px-3.5 py-2 text-xs font-medium text-[rgb(var(--color-fg))] transition-colors hover:border-[rgb(var(--color-border-strong))] hover:bg-[rgb(var(--color-bg-elevated))] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgb(var(--color-accent))] disabled:cursor-not-allowed disabled:opacity-40"
                        >
                            {isBusy && busy?.action === 'validate' ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                                <ShieldCheck className="h-3.5 w-3.5" />
                            )}
                            Validate
                        </button>

                        {isLoaded ? (
                            <button
                                type="button"
                                disabled={!canUnload}
                                onClick={() => onAction(model.manifest_id, 'unload')}
                                className="inline-flex min-h-9 items-center justify-center gap-2 rounded-lg border border-[rgb(var(--color-danger)/0.3)] bg-[rgb(var(--color-danger)/0.09)] px-3.5 py-2 text-xs font-medium text-[rgb(var(--color-danger))] transition-colors hover:bg-[rgb(var(--color-danger)/0.13)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400 disabled:cursor-not-allowed disabled:opacity-40"
                            >
                                {isBusy && busy?.action === 'unload' ? (
                                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                ) : (
                                    <StopCircle className="h-3.5 w-3.5" />
                                )}
                                Unload model
                            </button>
                        ) : (
                            <button
                                type="button"
                                disabled={!canLoad}
                                onClick={() => onAction(model.manifest_id, 'load')}
                                className="inline-flex min-h-9 items-center justify-center gap-2 rounded-lg bg-[rgb(var(--color-accent))] px-4 py-2 text-xs font-semibold text-[#29221a] transition-colors hover:bg-[rgb(var(--color-accent-hover))] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgb(var(--color-accent))] disabled:cursor-not-allowed disabled:opacity-40"
                            >
                                {isBusy && busy?.action === 'load' ? (
                                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                ) : isLoading ? (
                                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                ) : (
                                    <Play className="h-3.5 w-3.5 fill-current" />
                                )}

                                {isLoading ? 'Loading' : 'Load model'}
                            </button>
                        )}

                        <button
                            type="button"
                            onClick={() => setDetailsOpen(value => !value)}
                            aria-expanded={detailsOpen}
                            aria-label={`${detailsOpen ? 'Hide' : 'Show'} details for ${model.definition.display_name}`}
                            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[rgb(var(--color-border))] text-[rgb(var(--color-fg-muted))] transition-colors hover:bg-[rgb(var(--color-bg-elevated))] hover:text-[rgb(var(--color-fg))] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgb(var(--color-accent))]"
                        >
                            <ChevronDown
                                className={`h-4 w-4 transition-transform ${detailsOpen ? 'rotate-180' : ''}`}
                            />
                        </button>
                    </div>
                </div>
            </div>

            {detailsOpen && (
                <div className="border-t border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-elevated))] px-5 py-5 sm:px-6">
                    <h4 className="mb-4 text-xs font-semibold uppercase tracking-wider text-[rgb(var(--color-fg-muted))]">
                        Installation details
                    </h4>

                    <dl className="grid gap-x-8 gap-y-4 sm:grid-cols-2 lg:grid-cols-3">
                        {[
                            ['Model ID', model.manifest_id],
                            ['Architecture', model.definition.architecture],
                            ['Runtime', model.runtime],
                            ['Device', model.device],
                            ['Quantization', model.quantization ?? 'Default'],
                            ['Installation', model.installation_state],
                            ['Loading state', model.loading_state],
                            [
                                'Memory estimate',
                                model.memory_estimate_mb != null
                                    ? `${model.memory_estimate_mb} MB`
                                    : 'Not available',
                            ],
                            [
                                'Languages',
                                model.definition.languages.join(', ') || 'Not specified',
                            ],
                        ].map(([label, value]) => (
                            <div key={label} className="min-w-0">
                                <dt className="text-xs text-[rgb(var(--color-fg-subtle))]">
                                    {label}
                                </dt>

                                <dd className="mt-1 break-all text-xs font-medium text-[rgb(var(--color-fg))]">
                                    {value}
                                </dd>
                            </div>
                        ))}
                    </dl>

                    <div className="mt-5 border-t border-[rgb(var(--color-border))] pt-4">
                        <p className="text-xs text-[rgb(var(--color-fg-subtle))]">
                            Local model path
                        </p>

                        <p className="mt-1 break-all font-mono text-xs text-[rgb(var(--color-fg))]">
                            {model.model_path}
                        </p>
                    </div>
                </div>
            )}
        </article>
    )
}

export default function ModelsPage() {
    const [models, setModels] = useState<ModelInstallationOut[]>([])
    const [loading, setLoading] = useState(true)
    const [refreshing, setRefreshing] = useState(false)

    const [error, setError] = useState('')
    const [notice, setNotice] = useState('')

    const [busy, setBusy] = useState<BusyOperation>(null)

    const [search, setSearch] = useState('')
    const [filter, setFilter] = useState<Filter>('all')

    const mountedRef = useRef(false)
    const requestIdRef = useRef(0)
    const operationRef = useRef(false)

    const fetchModels = useCallback(async (initial = false) => {
        const requestId = ++requestIdRef.current

        if (initial) {
            setLoading(true)
        } else {
            setRefreshing(true)
        }

        setError('')

        try {
            const result = await api.models.list()

            if (!mountedRef.current || requestId !== requestIdRef.current) {
                return
            }

            setModels(result)
        } catch (err) {
            if (!mountedRef.current || requestId !== requestIdRef.current) {
                return
            }

            setError(
                getErrorMessage(err, 'Unable to connect to the backend.')
            )
        } finally {
            if (mountedRef.current && requestId === requestIdRef.current) {
                setLoading(false)
                setRefreshing(false)
            }
        }
    }, [])

    useEffect(() => {
        mountedRef.current = true
        void fetchModels(true)

        return () => {
            mountedRef.current = false
            requestIdRef.current += 1
        }
    }, [fetchModels])

    async function handleAction(
        manifestId: string,
        action: ModelAction
    ) {
        if (operationRef.current) return

        operationRef.current = true
        setBusy({ id: manifestId, action })
        setError('')
        setNotice('')

        try {
            if (action === 'validate') {
                const result = await api.models.validate(manifestId)

                if (!result.valid) {
                    setError(
                        result.errors.length
                            ? `${manifestId}: ${result.errors.join('; ')}`
                            : `${manifestId}: Validation failed.`
                    )
                } else {
                    setNotice(`${manifestId}: Validation passed.`)
                }
            }

            if (action === 'load') {
                await api.models.load(manifestId)

                setNotice(
                    `${manifestId}: Load request accepted. Check the model state for progress.`
                )
            }

            if (action === 'unload') {
                await api.models.unload(manifestId)

                setNotice(
                    `${manifestId}: Unload request accepted.`
                )
            }

            await fetchModels()
        } catch (err) {
            if (mountedRef.current) {
                setError(
                    getErrorMessage(
                        err,
                        'The requested model operation failed.'
                    )
                )
            }
        } finally {
            operationRef.current = false

            if (mountedRef.current) {
                setBusy(null)
            }
        }
    }

    // Refresh transient loading states without requiring manual intervention.
    // The backend remains authoritative for success and failure.
    const hasLoadingModel = models.some(model => model.loading_state === 'loading')

    useEffect(() => {
        if (!hasLoadingModel) return

        const interval = window.setInterval(() => {
            if (!document.hidden && !operationRef.current) {
                void fetchModels()
            }
        }, 3000)

        return () => window.clearInterval(interval)
    }, [hasLoadingModel, fetchModels])

    const counts = useMemo(() => ({
        installed: models.length,
        active: models.filter(model => model.is_active_model).length,
        loaded: models.filter(
            model => model.loading_state === 'loaded'
        ).length,
    }), [models])

    const filteredModels = useMemo(() => {
        const query = search.trim().toLowerCase()

        return models.filter(model => {
            const searchable = [
                model.definition.display_name,
                model.manifest_id,
                model.runtime,
                model.device,
                model.quantization ?? '',
            ].join(' ').toLowerCase()

            if (query && !searchable.includes(query)) {
                return false
            }

            if (filter === 'loaded') {
                return model.loading_state === 'loaded'
            }

            if (filter === 'unloaded') {
                return model.loading_state === 'unloaded'
            }

            if (filter === 'errors') {
                return (
                    model.loading_state === 'error' ||
                    model.installation_state === 'invalid'
                )
            }

            return true
        })
    }, [models, search, filter])

    const filters: { id: Filter; label: string }[] = [
        { id: 'all', label: 'All models' },
        { id: 'loaded', label: 'Loaded' },
        { id: 'unloaded', label: 'Unloaded' },
        { id: 'errors', label: 'Errors' },
    ]

    return (
        <main className="mx-auto w-full max-w-7xl space-y-7 px-4 py-6 text-[rgb(var(--color-fg))] sm:px-6 lg:px-8">
            <header className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
                <div>
                    <div className="mb-3 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-[rgb(var(--color-fg-subtle))]">
                        <Server className="h-3.5 w-3.5" />
                        Local inference
                        <span className="text-[rgb(var(--color-fg-subtle))]">/</span>
                        Models
                    </div>

                    <h1 className="text-2xl font-semibold tracking-tight text-[rgb(var(--color-fg))] sm:text-[28px]">
                        Model Registry
                    </h1>

                    <p className="mt-2 max-w-2xl text-sm leading-6 text-[rgb(var(--color-fg-muted))]">
                        Manage installed speech models, verify their configuration,
                        and control local inference runtimes.
                    </p>
                </div>

                <button
                    type="button"
                    onClick={() => void fetchModels()}
                    disabled={loading || refreshing || busy !== null}
                    className="inline-flex h-10 shrink-0 items-center justify-center gap-2 self-start rounded-lg border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))] px-4 text-xs font-semibold text-[rgb(var(--color-fg))] transition-colors hover:border-[rgb(var(--color-border-strong))] hover:bg-[rgb(var(--color-bg-elevated))] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgb(var(--color-accent))] disabled:cursor-not-allowed disabled:opacity-40"
                >
                    <RefreshCw
                        className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`}
                    />
                    {refreshing ? 'Refreshing' : 'Refresh models'}
                </button>
            </header>

            {error && (
                <div
                    role="alert"
                    className="flex items-start gap-3 rounded-lg border border-[rgb(var(--color-danger)/0.25)] bg-[rgb(var(--color-danger)/0.06)] px-4 py-3"
                >
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-[rgb(var(--color-danger))]" />

                    <p className="flex-1 text-sm leading-5 text-[rgb(var(--color-danger))]">
                        {error}
                    </p>

                    <button
                        type="button"
                        onClick={() => setError('')}
                        aria-label="Dismiss error"
                        className="text-[rgb(var(--color-danger))] hover:text-[rgb(var(--color-fg))]"
                    >
                        <X className="h-4 w-4" />
                    </button>
                </div>
            )}

            {notice && (
                <div
                    role="status"
                    className="flex items-start gap-3 rounded-lg border border-[rgb(var(--color-accent)/0.3)] bg-[rgb(var(--color-accent)/0.08)] px-4 py-3"
                >
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-[rgb(142_91_34)]" />

                    <p className="flex-1 text-sm leading-5 text-[rgb(var(--color-fg))]">
                        {notice}
                    </p>

                    <button
                        type="button"
                        onClick={() => setNotice('')}
                        aria-label="Dismiss notification"
                        className="text-[rgb(var(--color-fg-muted))] hover:text-[rgb(var(--color-fg))]"
                    >
                        <X className="h-4 w-4" />
                    </button>
                </div>
            )}

            <section
                aria-label="Model statistics"
                className="grid gap-3 sm:grid-cols-3"
            >
                <StatCard
                    label="Registered models"
                    value={counts.installed}
                    description="Available installations"
                    icon={Database}
                />

                <StatCard
                    label="Active models"
                    value={counts.active}
                    description="Marked active by the backend"
                    icon={Activity}
                />

                <StatCard
                    label="Loaded models"
                    value={counts.loaded}
                    description="Reported as loaded"
                    icon={Cpu}
                />
            </section>

            <section className="space-y-4">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                    <div>
                        <h2 className="text-base font-semibold text-[rgb(var(--color-fg))]">
                            Available installations
                        </h2>

                        <p className="mt-1 text-xs text-[rgb(var(--color-fg-subtle))]">
                            Browse and manage models configured on this machine.
                        </p>
                    </div>

                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                        <div className="relative">
                            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[rgb(var(--color-fg-subtle))]" />

                            <input
                                type="search"
                                value={search}
                                onChange={event => setSearch(event.target.value)}
                                placeholder="Search models..."
                                aria-label="Search models"
                                className="h-10 w-full rounded-lg border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))] pl-9 pr-3 text-xs text-[rgb(var(--color-fg))] outline-none placeholder:text-[rgb(var(--color-fg-subtle))] focus:border-[rgb(var(--color-accent-hover))] sm:w-56"
                            />
                        </div>

                        <div className="flex items-center gap-1 rounded-lg border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))] p-1">
                            <SlidersHorizontal className="ml-2 mr-1 h-3.5 w-3.5 text-[rgb(var(--color-fg-subtle))]" />

                            {filters.map(item => (
                                <button
                                    key={item.id}
                                    type="button"
                                    onClick={() => setFilter(item.id)}
                                    aria-pressed={filter === item.id}
                                    className={`rounded-md px-2.5 py-1.5 text-[11px] font-medium transition-colors ${filter === item.id
                                        ? 'bg-[rgb(var(--color-accent)/0.18)] text-[rgb(var(--color-fg))]'
                                        : 'text-[rgb(var(--color-fg-muted))] hover:bg-[rgb(var(--color-bg-elevated))] hover:text-[rgb(var(--color-fg))]'
                                        }`}
                                >
                                    {item.label}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                {loading ? (
                    <div className="flex min-h-52 flex-col items-center justify-center gap-3 rounded-xl border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))]">
                        <Loader2 className="h-6 w-6 animate-spin text-[rgb(var(--color-accent-hover))]" />

                        <p className="text-sm text-[rgb(var(--color-fg-muted))]">
                            Loading model registry...
                        </p>
                    </div>
                ) : models.length === 0 ? (
                    <div className="flex min-h-60 flex-col items-center justify-center rounded-xl border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))] px-6 text-center">
                        <HardDrive className="h-8 w-8 text-[rgb(var(--color-fg-subtle))]" />

                        <h3 className="mt-4 text-sm font-semibold text-[rgb(var(--color-fg))]">
                            No models registered
                        </h3>

                        <p className="mt-2 max-w-sm text-xs leading-5 text-[rgb(var(--color-fg-subtle))]">
                            The backend did not return any model installations.
                            Check your model registry configuration.
                        </p>
                    </div>
                ) : filteredModels.length === 0 ? (
                    <div className="flex min-h-52 flex-col items-center justify-center rounded-xl border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))] px-6 text-center">
                        <Search className="h-7 w-7 text-[rgb(var(--color-fg-subtle))]" />

                        <h3 className="mt-3 text-sm font-semibold text-[rgb(var(--color-fg))]">
                            No matching models
                        </h3>

                        <p className="mt-1 text-xs text-[rgb(var(--color-fg-subtle))]">
                            Try another search term or status filter.
                        </p>

                        <button
                            type="button"
                            onClick={() => {
                                setSearch('')
                                setFilter('all')
                            }}
                            className="mt-4 text-xs font-medium text-[rgb(142_91_34)] hover:text-[rgb(var(--color-accent-hover))]"
                        >
                            Clear filters
                        </button>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {filteredModels.map(model => (
                            <ModelCard
                                key={model.id}
                                model={model}
                                busy={busy}
                                onAction={(id, action) => {
                                    void handleAction(id, action)
                                }}
                            />
                        ))}
                    </div>
                )}

                {!loading && models.length > 0 && (
                    <div className="flex flex-wrap items-center justify-between gap-2 px-1 text-xs text-[rgb(var(--color-fg-subtle))]">
                        <span>
                            Showing {filteredModels.length} of {models.length} models
                        </span>

                        <span className="inline-flex items-center gap-1.5">
                            <Server className="h-3.5 w-3.5" />
                            Local model registry
                        </span>
                    </div>
                )}
            </section>

            <div className="flex items-start gap-3 rounded-lg border border-[rgb(var(--color-border))] bg-[rgb(var(--color-bg-muted))] px-4 py-3">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[rgb(var(--color-fg-muted))]" />

                <p className="text-xs leading-5 text-[rgb(var(--color-fg-muted))]">
                    Model states are reported by the backend. A successful load
                    request does not necessarily mean inference initialization
                    has completed. Refresh the registry to inspect the latest
                    reported state.
                </p>
            </div>
        </main>
    )
}
