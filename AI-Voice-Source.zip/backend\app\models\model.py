from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class ModelDefinition(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """Architecture-level description (e.g. 'Kokoro-82M', 'Qwen3-TTS 0.6B Base')."""

    __tablename__ = "model_definitions"

    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True, nullable=False)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    architecture: Mapped[str] = mapped_column(String(80), nullable=False)
    model_type: Mapped[str] = mapped_column(String(40), nullable=False)
    parameters_billions: Mapped[float] = mapped_column(Float, nullable=False)
    license: Mapped[str] = mapped_column(String(120), nullable=False)
    source_repository: Mapped[str] = mapped_column(String(500), nullable=False)
    languages: Mapped[list[str]] = mapped_column(JSON, nullable=False, default=list)
    capabilities: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

    installations: Mapped[list[ModelInstallation]] = relationship(
        back_populates="definition", cascade="all, delete-orphan"
    )


class ModelInstallation(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    """A local copy of a model, with runtime and installation state."""

    __tablename__ = "model_installations"

    definition_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("model_definitions.id", ondelete="CASCADE"), nullable=False, index=True
    )
    manifest_id: Mapped[str] = mapped_column(String(160), unique=True, index=True, nullable=False)
    runtime: Mapped[str] = mapped_column(String(40), nullable=False)
    quantization: Mapped[str | None] = mapped_column(String(40), nullable=True)
    device: Mapped[str] = mapped_column(String(20), nullable=False, default="cpu")
    model_path: Mapped[str] = mapped_column(String(1000), nullable=False)
    memory_estimate_mb: Mapped[int | None] = mapped_column(Integer, nullable=True)

    installation_state: Mapped[str] = mapped_column(
        String(30), nullable=False, default="registered"
    )  # registered | validated | invalid | installed
    loading_state: Mapped[str] = mapped_column(
        String(30), nullable=False, default="unloaded"
    )  # unloaded | loading | loaded | error
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_loaded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_validated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    is_active_model: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    definition: Mapped[ModelDefinition] = relationship(back_populates="installations")
    benchmarks: Mapped[list[ModelBenchmark]] = relationship(
        back_populates="installation", cascade="all, delete-orphan"
    )


class ModelBenchmark(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "model_benchmarks"

    installation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("model_installations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    sample_name: Mapped[str] = mapped_column(String(80), nullable=False)
    text_length_chars: Mapped[int] = mapped_column(Integer, nullable=False)
    generation_time_seconds: Mapped[float] = mapped_column(Float, nullable=False)
    audio_duration_seconds: Mapped[float] = mapped_column(Float, nullable=False)
    real_time_factor: Mapped[float] = mapped_column(Float, nullable=False)
    time_to_first_audio_seconds: Mapped[float | None] = mapped_column(Float, nullable=True)
    peak_ram_mb: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cpu_percent: Mapped[float | None] = mapped_column(Float, nullable=True)
    sample_rate: Mapped[int | None] = mapped_column(Integer, nullable=True)
    output_size_bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    cold_start: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    success: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    installation: Mapped[ModelInstallation] = relationship(back_populates="benchmarks")